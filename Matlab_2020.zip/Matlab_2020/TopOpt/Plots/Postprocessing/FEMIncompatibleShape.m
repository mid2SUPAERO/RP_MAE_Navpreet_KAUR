
function history = FEMIncompatibleShape(history)

    
        