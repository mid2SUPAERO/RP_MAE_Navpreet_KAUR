%Created by J.T.B. Overvelde - 18 April 2012
%Master's thesis - The Moving Noda Approach in Topology Optimization
%http://www.overvelde.com
%
%Provides the displacement, strain and stress of the analytical
%solution of a cantilever beam initialized in InitMesh at coordinate x.
%Also provides the compliance of the total beam.

function [u,e,s,C]=AnalSol(x)

GlobalConst
 
I=pCon.Ly^3/12;

%Displacement
u=zeros(2,1);
u(1)=pCon.P*x(2)/(6*pCon.E*I)*((6*pCon.Lx-3*x(1))*x(1)+(2+pCon.nu)*(x(2)^2-pCon.Ly^2/4));
u(2)=-pCon.P/(6*pCon.E*I)*(3*pCon.nu*x(2)^2*(pCon.Lx-x(1))+(4+5*pCon.nu)*pCon.Ly^2*x(1)/4+(3*pCon.Lx-x(1))*x(1)^2);

%Strain
e=zeros(3,1);
e(1)=pCon.P*x(2)/(6*pCon.E*I)*(6*pCon.Lx-6*x(1));
e(2)=-pCon.P/(6*pCon.E*I)*6*pCon.nu*x(2)*(pCon.Lx-x(1));
e(3)=1/2*(pCon.P/(6*pCon.E*I)*((6*pCon.Lx-3*x(1))*x(1)+(2+pCon.nu)*(3*x(2)^2-pCon.Ly^2/4))...
         -pCon.P/(6*pCon.E*I)*(-3*pCon.nu*x(2)^2+(4+5*pCon.nu)*pCon.Ly^2/4+(6*pCon.Lx-3*x(1))*x(1)));

%stress
s=zeros(3,1);
s(1)=pCon.P*(pCon.Lx-x(1))*x(2)/I;
s(2)=0;
s(3)=-pCon.P/(2*I)*(pCon.Ly^2/4-x(2)^2);

%Compliance
con=pCon.P^2/(12*pCon.E*I^2)*((4+5*pCon.nu)*pCon.Ly^2*pCon.Lx/4+2*pCon.Lx^3);
C=1/6*con*pCon.Ly^3;