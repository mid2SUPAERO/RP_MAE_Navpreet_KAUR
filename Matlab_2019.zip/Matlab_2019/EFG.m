%Created by J.T.B. Overvelde - 18 April 2012
%Master's thesis - The Moving Noda Approach in Topology Optimization
%http://www.overvelde.com
%
%Determines the stiffness matrix for given nodal distribution and
%background mesh and determines the displacement by solving the system of
%equations for given boundary conditions.

function [ug,ErrorNorm,Compliance,time1,time2,time3]=EFG(FindErrorNorm)

GlobalConst

tic %Assembly timer

%Assembly K matrix and f vector internal cells
K=zeros(2*mCon.n,2*mCon.n);
f=zeros(2*mCon.n,1);
for ic=1:mCon.m
    for ip=1:cells(ic).ni
        B=zeros(3,2*length(cells(ic).int(ip).nen));
        F=zeros(2*length(cells(ic).int(ip).nen),1);
        en=zeros(1,2*length(cells(ic).int(ip).nen));
        [phi,dphidx,dphidy]=MLSShape([nodes(cells(ic).int(ip).nen).x]',cells(ic).int(ip).x,mCon.dm,mCon.pn);
        B(1,1:2:end-1)=dphidx;
        B(2,2:2:end)=dphidy;
        B(3,1:2:end-1)=dphidy;
        B(3,2:2:end)=dphidx;
        F(1:2:end-1)=phi*cells(ic).int(ip).cv(1);
        F(2:2:end)=phi*cells(ic).int(ip).cv(2);
        en(1:2:end-1)=2*[cells(ic).int(ip).nen]-1;
        en(2:2:end)=2*[cells(ic).int(ip).nen];            
        K(en,en)=K(en,en)+B'*pCon.D*B*cells(ic).int(ip).w*cells(ic).J;
        f(en)=f(en)+F*cells(ic).int(ip).w*cells(ic).J;
        
    end
end

%Assembly G matrix and q vector boundary cells
G=zeros(2*mCon.n,2*mCon.me+bcCon.BCunx+bcCon.BCuny); q=zeros(2*mCon.me+bcCon.BCunx+bcCon.BCuny,1);
for ic=1:mCon.mb
    if bcells(ic).BC==1
        for in=1:2 %two-nodes element
            for ip=1:bcells(ic).ni
                U=zeros(2*length(bcells(ic).int(ip).nen),2);
                en=zeros(1,2*length(bcells(ic).int(ip).nen));
                [phi,dphidx,dphidy]=MLSShape([nodes(bcells(ic).int(ip).nen).x]',bcells(ic).int(ip).x,mCon.dm,mCon.pn);
                for neni=1:length(bcells(ic).int(ip).nen)
                    U(2*neni-1:2*neni,:)=phi(neni)*[bcells(ic).int(ip).N(in) 0; 0 bcells(ic).int(ip).N(in)];
                    en(2*neni-1:2*neni)=[2*bcells(ic).int(ip).nen(neni)-1; 2*bcells(ic).int(ip).nen(neni)];
                end
                q(2*bcells(ic).Ni(in)-1:2*bcells(ic).Ni(in))=q(2*bcells(ic).Ni(in)-1:2*bcells(ic).Ni(in))-[bcells(ic).int(ip).N(in) 0; 0 bcells(ic).int(ip).N(in)]*bcells(ic).int(ip).bv*bcells(ic).int(ip).w*bcells(ic).J;
                G(en,2*bcells(ic).Ni(in)-1:2*bcells(ic).Ni(in))=G(en,2*bcells(ic).Ni(in)-1:2*bcells(ic).Ni(in))-U*bcells(ic).int(ip).w*bcells(ic).J;
            end
        end
    elseif bcells(ic).BC==2
        for ip=1:bcells(ic).ni
            T=zeros(2*length(bcells(ic).int(ip).nen),1);
            en=zeros(1,2*length(bcells(ic).int(ip).nen));
            [phi,dphidx,dphidy]=MLSShape([nodes(bcells(ic).int(ip).nen).x]',bcells(ic).int(ip).x,mCon.dm,mCon.pn);
            for neni=1:length(bcells(ic).int(ip).nen)
                T(2*neni-1:2*neni)=phi(neni).*bcells(ic).int(ip).bv;
                en(2*neni-1:2*neni)=[2*bcells(ic).int(ip).nen(neni)-1; 2*bcells(ic).int(ip).nen(neni)];
            end
            f(en)=f(en)+T*bcells(ic).int(ip).w*bcells(ic).J;
        end        
    end
end
%Assembly G matrix and q vector collocatd boundary particles
if mCon.BCuType~=1
    for i=1:bcCon.BCunx
        q(i)=-bcCon.BCux(2,i);
        [phi_i,dphidx_i,dphidy_i]=MLSShape([nodes(nodes(bcCon.BCux(1,i)).nen).x]',nodes(bcCon.BCux(1,i)).x,mCon.dm,mCon.pn);
        nj=0;
        for j=nodes(bcCon.BCux(1,i)).nen
            nj=nj+1;
            G(2*j-1,i)=G(2*j-1,i)-phi_i(nj);
        end
    end
    for i=1:bcCon.BCuny
        q([i+bcCon.BCunx])=-bcCon.BCuy(2,i);
        [phi_i,dphidx_i,dphidy_i]=MLSShape([nodes(nodes(bcCon.BCuy(1,i)).nen).x]',nodes(bcCon.BCuy(1,i)).x,mCon.dm,mCon.pn);
        nj=0;
        for j=nodes(bcCon.BCuy(1,i)).nen
            nj=nj+1;
            G(2*j,i+bcCon.BCunx)=G(2*j,i+bcCon.BCunx)-phi_i(nj);
        end
    end
end

time1=toc; %Assembly timer
disp([num2str(time1),' seconds to assemble the matrices'])
tic %Solve timer

%Solve for the displacement constants belonging to the shape functions
K=sparse(K);
G=sparse(G);

r=[K G;G' zeros(length(q))]\[f;q];
ug(:,1)=r(1:2:end-length(q)-1);
ug(:,2)=r(2:2:end-length(q));

%clear r K G f q

time2=toc; %Solve timer
disp([num2str(time2),' seconds to solve the system'])
tic %Find nodal values timer

%Calculate the strains and stress constants belonging to the shape
%functions at the nodal positions
% eg=zeros(mCon.n,3); sg=zeros(mCon.n,3);
% for i=1:mCon.n
%     [phi,dphidx,dphidy]=MLSShape([nodes(nodes(i).nen).x]',nodes(i).x,mCon.dm,mCon.pn);
%     %strain
%     eg(i,1)=sum(dphidx.*ug([nodes(i).nen],1)'); 
%     eg(i,2)=sum(dphidy.*ug([nodes(i).nen],2)');
%     eg(i,3)=1/2*(sum(dphidx.*ug([nodes(i).nen],2)')...
%                  +sum(dphidy.*ug([nodes(i).nen],1)'));
%     %stress
%     sg(i,:)=pCon.D*eg(i,:)';
%     sg(i,3)=2*sg(i,3);
% end

time3=toc; %Find nodal values timer
disp([num2str(time3),' seconds to find the nodal values'])
tic %Find error norm
 
ErrorNorm=0; Compliance=0; %ComplianceAnalytic=0;
if FindErrorNorm==1
    Compliance=f'*r(1:end-length(q));
    ErrorNorm2=0;
    AnEnergy=0;
    for ic=1:mCon.m
        for ip=1:cells(ic).ni
            em=zeros(3,1);
            sm=zeros(3,1);
            [phi,dphidx,dphidy]=MLSShape([nodes(cells(ic).int(ip).nen).x]',cells(ic).int(ip).x,mCon.dm,mCon.pn);
            em(1)=sum(dphidx.*ug([cells(ic).int(ip).nen],1)'); 
            em(2)=sum(dphidy.*ug([cells(ic).int(ip).nen],2)');
            em(3)=1/2*(sum(dphidx.*ug([cells(ic).int(ip).nen],2)')...
                         +sum(dphidy.*ug([cells(ic).int(ip).nen],1)'));
            sm=pCon.D*em;
            sm(3)=2*sm(3);
            
            %em=eg([cells(ic).int(ip).nen],:)'*phi';
            %sm=sg([cells(ic).int(ip).nen],:)'*phi';
            [uma,ema,sma]=AnalSol(cells(ic).int(ip).x);
            ErrorNorm2=ErrorNorm2+(em-ema)'*(sm-sma)*cells(ic).int(ip).w*cells(ic).J;
            AnEnergy=AnEnergy+(ema)'*(sma)*cells(ic).int(ip).w*cells(ic).J;
        end
    end
    ErrorNorm=sqrt(ErrorNorm2)/sqrt(AnEnergy);
end
time4=toc;
disp([num2str(time4),' seconds to find the error norm and compliance'])


