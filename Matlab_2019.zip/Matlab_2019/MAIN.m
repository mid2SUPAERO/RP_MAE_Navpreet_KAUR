%Created by J.T.B. Overvelde - 18 April 2012
%Master's thesis - The Moving Noda Approach in Topology Optimization
%http://www.overvelde.com
%
%Main body of the EFG method for solving a cantilever beam
%problem. Run this file to perform calculation and plot the results.

clear, clear global, close all, clc;
%for i = 1:1000 
GlobalConst

%Make the Initial configuration of nodes and backgroundcells
%i
InitMesh();

%Find the displacement and stress
FindErrorNorm=1;
[ug,ErrorNorm,Compliance]=EFG(FindErrorNorm);
%error(i)=ErrorNorm;
%comp(i)=Compliance;
%end

%histogram(error);
%me=mean(error);
%sde=std(error);
%histogram(comp);
%mc=mean(comp);
%sdc=std(comp);

ErrorNorm
Compliance

%Plot everything
PlotMeshYN=1;
PlotResultYN=1;
PlotSome(PlotMeshYN,PlotResultYN,ug);

