%Created by J.T.B. Overvelde - 18 April 2012
%Master's thesis - The Moving Noda Approach in Topology Optimization
%http://www.overvelde.com
%
%Makes some constants global.

global pCon mCon sCon bcCon
global nodes cells bcells solnodes 