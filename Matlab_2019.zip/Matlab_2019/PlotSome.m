%Created by J.T.B. Overvelde - 18 April 2012
%Master's thesis - The Moving Noda Approach in Topology Optimization
%http://www.overvelde.com
%
%Plots the nodal distribution, displacement and stress.

function PlotSome(PlotMeshYN,PlotResultYN,ug,sg)

GlobalConst

tic %plot mesh timer

if PlotMeshYN==1
    %Plot the initial configuration
    figure, hold on
    %set(gcf,'Position',get(0,'ScreenSize'))
    plot([0 0 pCon.Lx pCon.Lx 0],[-pCon.Ly/2 pCon.Ly/2 pCon.Ly/2 -pCon.Ly/2 -pCon.Ly/2],'black','linewidth',2)
    for i=1:mCon.m
        x1=cells(i).x(1)-cells(i).dx(1)/2;
        x2=cells(i).x(1)+cells(i).dx(1)/2;
        y1=cells(i).x(2)-cells(i).dx(2)/2;
        y2=cells(i).x(2)+cells(i).dx(2)/2;
        plot([x1 x1 x2],[y1 y2 y2],'--','color','black')
    end
    x=[nodes.x]';
    plot(x(:,1),x(:,2),'o','color','b','linewidth',2)
    x=[];
    for i=1:mCon.m
        for j=1:cells(i).ni
            x=[x; cells(i).int(j).x(1) cells(i).int(j).x(2)];
        end
    end
    plot(x(:,1),x(:,2),'.','color','g','linewidth',2,'markersize',16)
    x=[];
    for i=1:mCon.mb
        for j=1:bcells(i).ni
            x=[x; bcells(i).int(j).x(1) bcells(i).int(j).x(2)];
        end
    end
    plot(x(:,1),x(:,2),'.','color','r','linewidth',2,'markersize',16)
    set(gca,'XTick',[-1;pCon.Lx])
    set(gca,'XTickLabel',['0';'L'])
    set(gca,'YTick',[-pCon.Ly/2;0;pCon.Ly/2])
    set(gca,'YTickLabel',['-D/2';' 0  ';' D/2'])
    set(gca,'fontsize',14)
    axis([-0.001*pCon.Lx +1.001*pCon.Lx -1.001*pCon.Ly/2 1.001*pCon.Ly/2])
end

time1=toc; %Plot mesh timer
disp([num2str(time1),' seconds to plot the problem'])
tic %Plot solution timer

%plot the deformed shape and stresses
%plot the timoshenko beam analytical solution
if PlotResultYN==1
    
    %find the nodal displacements and stresses by summing over the shape variables
    u=zeros(sCon.sn,2); s=zeros(sCon.sn,3);
    for i=1:sCon.sn
        [phi,dphidx,dphidy]=MLSShape([nodes(solnodes(i).nen).x]',solnodes(i).x,mCon.dm,mCon.pn);
        
        em=zeros(3,1);
        sm=zeros(3,1);
        em(1)=sum(dphidx.*ug([solnodes(i).nen],1)'); 
        em(2)=sum(dphidy.*ug([solnodes(i).nen],2)');
        em(3)=1/2*(sum(dphidx.*ug([solnodes(i).nen],2)')...
                     +sum(dphidy.*ug([solnodes(i).nen],1)'));
        sm=pCon.D*em;
        sm(3)=2*sm(3);
        u(i,1)=u(i,1)+ug([solnodes(i).nen],1)'*phi';
        u(i,2)=u(i,2)+ug([solnodes(i).nen],2)'*phi';
        s(i,:)=s(i,:)+sm';
    end
    
    figure, hold on
    %set(gcf,'Position',get(0,'ScreenSize'))
    x=[solnodes.x]';
    ua=zeros(sCon.sn,2);
    sa=zeros(sCon.sn,3);
    for i=1:sCon.sn
        [ua(i,:) ea sa(i,:)]=AnalSol(x(i,:));
    end
    %subplot(2,2,1), hold on
    plot(x(:,1)+u(:,1),x(:,2)+u(:,2),'*','color','g')
    plot(x(:,1)+ua(:,1),x(:,2)+ua(:,2),'o','color','r')
    %subplot(2,2,2), hold on
    %plot3(x(:,1),x(:,2),s(:,1),'*','color','b')
    %plot3(x(:,1),x(:,2),sa(:,1),'o','color','r')
    %subplot(2,2,3), hold on
    %plot3(x(:,1),x(:,2),s(:,2),'*','color','b')
    %plot3(x(:,1),x(:,2),sa(:,2),'o','color','r')
    %subplot(2,2,4), hold on
    %plot3(x(:,1),x(:,2),s(:,3),'*','color','b')
    %plot3(x(:,1),x(:,2),sa(:,3),'o','color','r')
    
    xm=zeros(sqrt(sCon.sn)); ym=xm; sxm=xm; sym=xm; sxym=xm;
    dsxm=xm; dsym=xm; dsxym=xm; uxm=xm; uym=xm; duxm=xm; duym=xm;
    for i=1:sCon.sn
        xm(solnodes(i).nx,solnodes(i).ny)=solnodes(i).x(1);
        ym(solnodes(i).nx,solnodes(i).ny)=solnodes(i).x(2);
        sxm(solnodes(i).nx,solnodes(i).ny)=s(i,1);
        sym(solnodes(i).nx,solnodes(i).ny)=s(i,2);
        sxym(solnodes(i).nx,solnodes(i).ny)=s(i,3);
        uxm(solnodes(i).nx,solnodes(i).ny)=u(i,1);
        uym(solnodes(i).nx,solnodes(i).ny)=u(i,2);
    end
    
    figure
    contourf(xm,ym,uxm,10), colorbar
    %surf(xm,ym,uxm), colorbar
    set(gca,'XTick',[0;pCon.Lx])
    set(gca,'XTickLabel',['0';'L'])
    set(gca,'YTick',[-pCon.Ly/2;0;pCon.Ly/2])
    set(gca,'YTickLabel',['-D/2';'   0';' D/2'])
    set(gca,'fontsize',14)
    caxis([min(min(uxm)) max(max(uxm))])
    
    figure
    contourf(xm,ym,uym,10), colorbar
    %surf(xm,ym,uym), colorbar
    set(gca,'XTick',[0;pCon.Lx])
    set(gca,'XTickLabel',['0';'L'])
    set(gca,'YTick',[-pCon.Ly/2;0;pCon.Ly/2])
    set(gca,'YTickLabel',['-D/2';'   0';' D/2'])
    set(gca,'fontsize',14)
    caxis([min(min(uym)) max(max(uym))])
    
    figure
    contourf(xm,ym,sxm,10), colorbar
    %surf(xm,ym,sxm), colorbar
    set(gca,'XTick',[0;pCon.Lx])
    set(gca,'XTickLabel',['0';'L'])
    set(gca,'YTick',[-pCon.Ly/2;0;pCon.Ly/2])
    set(gca,'YTickLabel',['-D/2';'   0';' D/2'])
    set(gca,'fontsize',14)
    caxis([min(min(sxm)) max(max(sxm))])
    
    figure
    contourf(xm,ym,sym,10), colorbar
    %surf(xm,ym,sym), colorbar
    set(gca,'XTick',[0;pCon.Lx])
    set(gca,'XTickLabel',['0';'L'])
    set(gca,'YTick',[-pCon.Ly/2;0;pCon.Ly/2])
    set(gca,'YTickLabel',['-D/2';'   0';' D/2'])
    set(gca,'fontsize',14)
    caxis([min(min(sym)) max(max(sym))])
    
    figure
    contourf(xm,ym,sxym,10), colorbar
    %surf(xm,ym,sxym), colorbar
    set(gca,'XTick',[0;pCon.Lx])
    set(gca,'XTickLabel',['0';'L'])
    set(gca,'YTick',[-pCon.Ly/2;0;pCon.Ly/2])
    set(gca,'YTickLabel',['-D/2';'   0';' D/2'])
    set(gca,'fontsize',14)
    caxis([min(min(sxym)) max(max(sxym))])
end

time2=toc; %plot solution timer
disp([num2str(time2),' seconds to plot the solution'])